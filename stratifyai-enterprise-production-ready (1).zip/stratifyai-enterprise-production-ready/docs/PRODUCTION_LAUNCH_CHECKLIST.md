# Production Launch Checklist

This checklist converts StratifyAI Enterprise from a local MVP into a real SaaS product. Complete these items before accepting production customers.

## 1. Accounts and infrastructure
- Create GitHub organization/repository.
- Create production hosting accounts: Vercel for frontend, Render/Railway/AWS for backend, Supabase/Neon/AWS RDS for Postgres.
- Create a Cloudflare account and connect your domain.
- Create production Stripe account and complete identity/business verification.
- Create a transactional email account such as Postmark, Resend, SendGrid, or AWS SES.

## 2. Required production environment variables
- `APP_ENV=production`
- `SECRET_KEY=<long random secret>`
- `DATABASE_URL=<production postgres url>`
- `CORS_ORIGINS=https://yourdomain.com`
- `FRONTEND_URL=https://yourdomain.com`
- `DEMO_PAYMENT_MODE=false`
- `STRIPE_SECRET_KEY=<live key>`
- `STRIPE_PRICE_ID=<live price id>`
- `STRIPE_WEBHOOK_SECRET=<webhook signing secret>`

## 3. Security hardening
- Replace local SQLite with Postgres.
- Enforce HTTPS only.
- Add production rate limiting.
- Add MFA or SSO for enterprise accounts.
- Add encrypted secrets management.
- Add daily database backups.
- Add vulnerability scanning in CI.
- Add central logging and alerting.
- Rotate all development/test secrets.

## 4. Legal/compliance
- Have an attorney review Privacy Policy, Terms of Service, DPA, and sales contract.
- Create a subprocessors page.
- Create a security page.
- Define support SLA and incident response policy.
- Create customer data deletion workflow.

## 5. Go-live tests
- Register a test account.
- Create a workspace.
- Run an assessment.
- Download a PDF report.
- Complete a Stripe test checkout.
- Complete a Stripe live checkout with a small test purchase.
- Confirm webhook updates the subscription.
- Confirm logs are created.
- Confirm backups run.
