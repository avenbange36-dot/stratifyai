# No-Docker Production Deployment Guide

## Frontend: Vercel
1. Push this project to GitHub.
2. In Vercel, import the repository.
3. Set the root directory to `frontend`.
4. Build command: `npm run build`.
5. Output directory: `dist`.
6. Add environment variable: `VITE_API_BASE_URL=https://your-backend-url`.
7. Add your domain in Vercel or route it through Cloudflare.

## Backend: Render
1. Create a new Web Service.
2. Connect the GitHub repository.
3. Set root directory to `backend`.
4. Build command: `pip install -r requirements.txt`.
5. Start command: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`.
6. Add production environment variables.

## Database: Supabase
1. Create a Supabase project.
2. Copy the direct Postgres connection string.
3. Set it as `DATABASE_URL` in Render.
4. Use the production database only with production environment.

## Stripe
1. Create a product.
2. Create a recurring price.
3. Copy the live price ID into `STRIPE_PRICE_ID`.
4. Add a webhook endpoint: `https://your-backend-url/api/billing/webhook`.
5. Subscribe to `checkout.session.completed`.
6. Copy the webhook signing secret into `STRIPE_WEBHOOK_SECRET`.
7. Set `DEMO_PAYMENT_MODE=false`.
