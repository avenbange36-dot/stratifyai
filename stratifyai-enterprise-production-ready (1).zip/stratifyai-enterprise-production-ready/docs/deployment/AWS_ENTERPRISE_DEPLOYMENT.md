# AWS Enterprise Deployment Blueprint

For a larger enterprise deployment, use this architecture.

## Services
- Route 53: DNS.
- CloudFront: CDN.
- AWS WAF: firewall.
- S3: static frontend hosting or report storage.
- ECS Fargate or App Runner: backend API.
- RDS Postgres: production database.
- Secrets Manager: secrets.
- CloudWatch: logs and metrics.
- GuardDuty: threat detection.
- AWS Backup: database backups.

## Environments
- dev
- staging
- production

## Required production controls
- Private database subnets.
- TLS everywhere.
- IAM least privilege.
- Log retention policy.
- Backups and restore testing.
- Security groups locked to known traffic paths.
- CI/CD with manual production approval.
