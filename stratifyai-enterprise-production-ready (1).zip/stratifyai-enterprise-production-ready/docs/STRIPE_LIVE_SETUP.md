# Stripe Live Payment Setup

## Steps
1. Create or log in to your Stripe account.
2. Complete business verification.
3. Create a product named StratifyAI Enterprise.
4. Create prices for Starter, Professional, and Enterprise.
5. Copy the live recurring price ID into `.env` as `STRIPE_PRICE_ID`.
6. Add your live secret key to `.env` as `STRIPE_SECRET_KEY`.
7. Add webhook endpoint: `https://your-backend-url/api/billing/webhook`.
8. Subscribe to `checkout.session.completed`.
9. Copy webhook signing secret into `.env` as `STRIPE_WEBHOOK_SECRET`.
10. Set `DEMO_PAYMENT_MODE=false`.

## Verification
- Create a test account.
- Click subscribe.
- Complete checkout.
- Confirm Stripe shows an active subscription.
- Confirm your database subscription status changes to active.

## Important
Never commit Stripe keys to GitHub.
