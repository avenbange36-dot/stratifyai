# Operations Runbook

## Daily checks
- Confirm API health endpoint responds.
- Check error monitoring.
- Check failed Stripe webhooks.
- Check database backup status.

## Incident response
1. Identify severity.
2. Assign incident owner.
3. Preserve logs.
4. Contain the issue.
5. Notify affected customers if required.
6. Remediate.
7. Write postmortem.

## Backup restore test
- Restore latest backup to staging.
- Confirm app can connect.
- Confirm sample records exist.
- Document test date and result.

## Customer deletion request
1. Verify requester authority.
2. Export customer data if requested.
3. Delete active database records.
4. Queue backup deletion according to retention policy.
5. Log completion.
