# Security Program

## Current security features included in the foundation
- Passwords are hashed with PBKDF2.
- JWT authentication is included.
- CORS is configurable through environment variables.
- Audit log database model and endpoints are included.
- Stripe webhook endpoint is included.
- SSO configuration storage is included as a placeholder.
- Security control tracking endpoint is included.

## Security controls still required for production
- Real SAML/OIDC implementation using Auth0, WorkOS, Clerk Enterprise, Okta SDK, or another trusted provider.
- MFA enforcement for admins and enterprise customers.
- Rate limiting middleware at API gateway or app layer.
- Web application firewall.
- Centralized logs and alerting.
- Secrets manager.
- Dependency vulnerability scanning.
- Penetration test.
- Secure software development lifecycle.

## Recommended baseline
- Host backend behind HTTPS only.
- Use Postgres with encrypted storage and daily backups.
- Use least-privilege database credentials.
- Rotate secrets every 90 days or after any suspected exposure.
- Keep separate dev, staging, and production environments.
- Require code review before production deployment.
