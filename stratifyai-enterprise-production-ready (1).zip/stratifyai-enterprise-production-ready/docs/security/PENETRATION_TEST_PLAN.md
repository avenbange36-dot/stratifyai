# Penetration Test Plan

## Scope
- Public marketing website.
- API endpoints under `/api`.
- Authentication and session handling.
- Payment workflow and webhook handling.
- PDF report generation.
- Organization/workspace isolation.

## Tests to perform
- Broken access control.
- Authentication bypass.
- SQL injection.
- Cross-site scripting.
- Cross-site request forgery.
- Server-side request forgery.
- Insecure direct object references.
- File download abuse.
- Stripe webhook spoofing.
- Rate limit bypass.
- Secrets exposure.

## Before test
- Create staging environment.
- Seed staging with fake data only.
- Provide test accounts and roles.
- Define test window and emergency contacts.

## After test
- Triage findings by severity.
- Fix critical/high findings before launch.
- Retest fixed issues.
- Store report as SOC 2 evidence.
