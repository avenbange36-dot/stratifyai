# Deployment Guide

## Beginner cloud stack

- Frontend: Vercel
- Backend: Render
- Database: Supabase Postgres
- Payments: Stripe

## Backend start command

```bash
uvicorn app.main:app --host 0.0.0.0 --port $PORT
```

## Frontend build command

```bash
npm run build
```

## Required environment variables

Set the values from `.env.example` in your hosting provider.

For production, set a long random `SECRET_KEY`, set `DEMO_PAYMENT_MODE=false`, and use real Stripe keys.
