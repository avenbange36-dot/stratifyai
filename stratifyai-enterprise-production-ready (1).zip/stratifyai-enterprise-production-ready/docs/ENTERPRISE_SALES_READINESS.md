# Enterprise Sales Readiness

## Required buyer assets
- Security overview.
- Privacy policy.
- Terms of service.
- DPA.
- Subprocessors page.
- Sample AI readiness report.
- Sample executive roadmap.
- One-page product overview.
- Pricing and packaging.

## Enterprise objections to prepare for
- How is customer data protected?
- Do you support SSO/SAML?
- Are you SOC 2 certified?
- Can data stay in the United States or EU?
- Do you train models on our data?
- Can we export or delete our data?
- What happens if recommendations are wrong?

## Recommended early offer
Sell a managed AI Opportunity Assessment first, with software access bundled into the engagement.
