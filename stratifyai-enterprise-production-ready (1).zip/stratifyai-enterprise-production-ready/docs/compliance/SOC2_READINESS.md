# SOC 2 Readiness Plan

This is not a SOC 2 certification. It is a starter plan for preparing for one.

## Trust Services Criteria focus
- Security: access controls, vulnerability management, incident response.
- Availability: uptime monitoring, backups, disaster recovery.
- Confidentiality: encryption, data access restrictions, vendor controls.
- Privacy: data collection notices, deletion process, subprocessors.

## Evidence to collect
- Access reviews.
- Security training completion.
- Vendor risk reviews.
- Change management approvals.
- Incident response tests.
- Backup restoration tests.
- Penetration test reports.
- Vulnerability scan results.
- Logging and monitoring evidence.

## Suggested tools
- Vanta, Drata, Secureframe, Sprinto, or Thoropass for compliance automation.
- Sentry or Datadog for monitoring.
- GitHub Advanced Security or Snyk for code scanning.
- Cloudflare for WAF and DNS security.

## Policy set to create
- Information Security Policy.
- Access Control Policy.
- Incident Response Policy.
- Business Continuity Policy.
- Vendor Risk Management Policy.
- Data Retention and Deletion Policy.
- Secure Development Policy.
