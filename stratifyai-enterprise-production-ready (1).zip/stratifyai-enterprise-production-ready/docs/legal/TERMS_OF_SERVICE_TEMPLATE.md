# Terms of Service Template

This is a template, not legal advice. Have an attorney review before publishing.

## Service
StratifyAI Enterprise provides AI readiness assessment, roadmap, governance, and reporting tools.

## Accounts
Users are responsible for account security and authorized use.

## Acceptable Use
Users may not abuse the service, attempt unauthorized access, upload unlawful data, or interfere with platform security.

## AI Outputs
AI-generated recommendations are decision-support materials and should be reviewed by qualified personnel before implementation.

## Fees
Paid subscriptions are billed through the configured payment processor. Refund terms should be defined in your commercial agreement.

## Limitation of Liability
Add attorney-reviewed liability language appropriate for your jurisdiction and customer segment.

## Termination
Define account termination, customer data export, and deletion procedures.
