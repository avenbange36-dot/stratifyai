# Privacy Policy Template

This is a template, not legal advice. Have an attorney review before publishing.

## Information We Collect
We may collect account information, company information, assessment inputs, billing metadata, usage logs, and support communications.

## How We Use Information
We use information to provide the platform, generate reports, manage accounts, process payments, improve the service, detect security issues, and provide support.

## Customer Data
Customer assessment data belongs to the customer. We do not sell customer data.

## AI Processing
If AI-powered features are enabled, customer-provided inputs may be processed by configured AI providers to generate recommendations and reports. Customers should not submit regulated sensitive data unless a written agreement permits it.

## Subprocessors
Maintain a public list of subprocessors, such as hosting, database, payments, analytics, support, and AI providers.

## Data Retention
Define retention periods for account data, assessment data, logs, and backups. Provide a deletion workflow.

## Contact
Privacy contact: privacy@yourdomain.com
