# Data Processing Addendum Template

This is a template, not legal advice. Have an attorney review before enterprise use.

## Roles
Customer is the controller/business. Provider is the processor/service provider for customer data.

## Processing Purpose
Provider processes customer data to operate the AI consulting platform, generate assessments, produce reports, provide support, and maintain security.

## Security Measures
- Access controls.
- Encryption in transit.
- Backups.
- Logging.
- Vendor management.
- Incident response.

## Subprocessors
Provider must maintain a subprocessors list and notify customers of material changes.

## Data Subject Requests
Provider will reasonably assist customer with access, correction, deletion, and export requests.

## Deletion
Provider will delete or return customer data after termination according to the agreement.
