# SSO Setup Plan

The codebase includes SSO configuration storage and `/api/auth/sso/start` as a placeholder endpoint. For real production SSO, connect a proven identity provider integration.

## Recommended vendors
- WorkOS for fast enterprise SSO and directory sync.
- Auth0 for flexible identity management.
- Clerk Enterprise for SaaS-friendly auth.
- Okta SDK if customers standardize on Okta.

## Implementation tasks
1. Choose SAML/OIDC provider.
2. Replace `/api/auth/sso/start` with a real redirect flow.
3. Add callback endpoint.
4. Validate signed SAML/OIDC responses.
5. Map IdP users to organization records.
6. Enforce domain ownership.
7. Add SCIM/directory sync if required.
8. Add JIT provisioning rules.
9. Log all SSO events in `audit_logs`.

## Minimum enterprise requirement
- SSO for customer admins.
- MFA at IdP level.
- Domain verification.
- Ability to disable password login for SSO-only organizations.
