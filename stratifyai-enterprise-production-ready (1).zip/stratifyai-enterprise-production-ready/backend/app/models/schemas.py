from pydantic import BaseModel, EmailStr, Field
from typing import Optional, List
from datetime import datetime

class UserCreate(BaseModel):
    email: EmailStr
    full_name: str = Field(min_length=2)
    password: str = Field(min_length=8)

class UserOut(BaseModel):
    id: int
    email: str
    full_name: str
    role: str
    mfa_enabled: bool = False
    class Config:
        from_attributes = True

class Token(BaseModel):
    access_token: str
    token_type: str = 'bearer'
    user: UserOut

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class OrganizationCreate(BaseModel):
    name: str
    industry: str = 'General Enterprise'
    employee_count: int = 0
    annual_revenue_usd: float = 0
    website: str = ''
    security_contact_email: str = ''
    data_region: str = 'US'

class OrganizationOut(BaseModel):
    id: int
    name: str
    industry: str
    employee_count: int
    annual_revenue_usd: float
    website: str
    security_contact_email: str = ''
    data_region: str = 'US'
    class Config:
        from_attributes = True

class AssessmentCreate(BaseModel):
    organization_id: int
    data_quality: int = Field(ge=1, le=5)
    executive_alignment: int = Field(ge=1, le=5)
    ai_governance: int = Field(ge=1, le=5)
    security_maturity: int = Field(ge=1, le=5)
    process_standardization: int = Field(ge=1, le=5)
    change_management: int = Field(ge=1, le=5)
    goals: List[str] = []
    pain_points: List[str] = []

class AssessmentOut(BaseModel):
    id: int
    organization_id: int
    readiness_score: float
    maturity_band: str
    goals: str
    pain_points: str
    class Config:
        from_attributes = True

class CheckoutRequest(BaseModel):
    organization_id: int
    plan: str = 'professional'

class ProfileUpdate(BaseModel):
    full_name: Optional[str] = None
    password: Optional[str] = Field(default=None, min_length=8)

class SSOConfigIn(BaseModel):
    organization_id: int
    provider: str = 'saml'
    domain: str = ''
    metadata_url: str = ''
    entity_id: str = ''
    sso_url: str = ''
    x509_cert: str = ''
    enabled: bool = False

class SSOConfigOut(SSOConfigIn):
    id: int
    class Config:
        from_attributes = True

class AuditLogOut(BaseModel):
    id: int
    organization_id: Optional[int]
    actor_user_id: Optional[int]
    action: str
    resource_type: str
    resource_id: str
    ip_address: str
    user_agent: str
    details: str
    created_at: datetime
    class Config:
        from_attributes = True

class ControlUpdate(BaseModel):
    organization_id: int
    control_id: str
    title: str
    status: str = 'planned'
    owner: str = ''
    evidence_url: str = ''
