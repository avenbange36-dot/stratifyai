from datetime import datetime
from sqlalchemy import Boolean, Column, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship
from app.db.session import Base

class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True, index=True)
    email = Column(String(255), unique=True, index=True, nullable=False)
    full_name = Column(String(255), nullable=False)
    hashed_password = Column(String(255), nullable=False)
    role = Column(String(50), default='owner')
    is_active = Column(Boolean, default=True)
    mfa_enabled = Column(Boolean, default=False)
    last_login_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    organizations = relationship('Organization', back_populates='owner')

class Organization(Base):
    __tablename__ = 'organizations'
    id = Column(Integer, primary_key=True, index=True)
    owner_id = Column(Integer, ForeignKey('users.id'), nullable=False)
    name = Column(String(255), nullable=False)
    industry = Column(String(255), default='General Enterprise')
    employee_count = Column(Integer, default=0)
    annual_revenue_usd = Column(Float, default=0)
    website = Column(String(255), default='')
    security_contact_email = Column(String(255), default='')
    data_region = Column(String(100), default='US')
    created_at = Column(DateTime, default=datetime.utcnow)
    owner = relationship('User', back_populates='organizations')
    assessments = relationship('Assessment', back_populates='organization')
    subscription = relationship('Subscription', back_populates='organization', uselist=False)
    sso_config = relationship('EnterpriseSSOConfig', back_populates='organization', uselist=False)

class Subscription(Base):
    __tablename__ = 'subscriptions'
    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey('organizations.id'), nullable=False)
    plan = Column(String(100), default='starter')
    status = Column(String(100), default='trial')
    stripe_customer_id = Column(String(255), default='')
    stripe_subscription_id = Column(String(255), default='')
    current_period_end = Column(DateTime, nullable=True)
    organization = relationship('Organization', back_populates='subscription')

class Assessment(Base):
    __tablename__ = 'assessments'
    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey('organizations.id'), nullable=False)
    data_quality = Column(Integer, default=3)
    executive_alignment = Column(Integer, default=3)
    ai_governance = Column(Integer, default=2)
    security_maturity = Column(Integer, default=3)
    process_standardization = Column(Integer, default=3)
    change_management = Column(Integer, default=3)
    goals = Column(Text, default='')
    pain_points = Column(Text, default='')
    readiness_score = Column(Float, default=0)
    maturity_band = Column(String(100), default='')
    created_at = Column(DateTime, default=datetime.utcnow)
    organization = relationship('Organization', back_populates='assessments')

class EnterpriseSSOConfig(Base):
    __tablename__ = 'enterprise_sso_configs'
    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey('organizations.id'), nullable=False)
    provider = Column(String(50), default='saml')
    domain = Column(String(255), default='')
    metadata_url = Column(String(512), default='')
    entity_id = Column(String(512), default='')
    sso_url = Column(String(512), default='')
    x509_cert = Column(Text, default='')
    enabled = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow)
    organization = relationship('Organization', back_populates='sso_config')

class AuditLog(Base):
    __tablename__ = 'audit_logs'
    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, nullable=True, index=True)
    actor_user_id = Column(Integer, nullable=True, index=True)
    action = Column(String(255), nullable=False)
    resource_type = Column(String(100), default='')
    resource_id = Column(String(100), default='')
    ip_address = Column(String(100), default='')
    user_agent = Column(String(512), default='')
    details = Column(Text, default='{}')
    created_at = Column(DateTime, default=datetime.utcnow, index=True)

class SecurityControl(Base):
    __tablename__ = 'security_controls'
    id = Column(Integer, primary_key=True, index=True)
    organization_id = Column(Integer, ForeignKey('organizations.id'), nullable=False)
    control_id = Column(String(100), nullable=False)
    title = Column(String(255), nullable=False)
    status = Column(String(50), default='planned')
    owner = Column(String(255), default='')
    evidence_url = Column(String(512), default='')
    updated_at = Column(DateTime, default=datetime.utcnow)
