from datetime import datetime, timedelta, timezone
from typing import Optional
from jose import jwt, JWTError
import os
import hashlib
import hmac
from fastapi import Depends, HTTPException, status
from fastapi.security import OAuth2PasswordBearer
from sqlalchemy.orm import Session
from app.core.config import get_settings
from app.db.session import get_db
from app.models.db_models import User

oauth2_scheme = OAuth2PasswordBearer(tokenUrl='/api/auth/login')
ALGORITHM = 'HS256'

def hash_password(password: str) -> str:
    salt = os.urandom(16)
    digest = hashlib.pbkdf2_hmac('sha256', password.encode('utf-8'), salt, 200000)
    return 'pbkdf2_sha256$200000$' + salt.hex() + '$' + digest.hex()

def verify_password(plain: str, hashed: str) -> bool:
    try:
        algorithm, iterations, salt_hex, digest_hex = hashed.split('$')
        if algorithm != 'pbkdf2_sha256':
            return False
        test = hashlib.pbkdf2_hmac('sha256', plain.encode('utf-8'), bytes.fromhex(salt_hex), int(iterations)).hex()
        return hmac.compare_digest(test, digest_hex)
    except Exception:
        return False

def create_access_token(subject: str, expires_delta: Optional[timedelta] = None) -> str:
    settings = get_settings()
    expire = datetime.now(timezone.utc) + (expires_delta or timedelta(minutes=settings.access_token_expire_minutes))
    return jwt.encode({'sub': subject, 'exp': expire}, settings.secret_key, algorithm=ALGORITHM)

def get_current_user(token: str = Depends(oauth2_scheme), db: Session = Depends(get_db)) -> User:
    settings = get_settings()
    credentials_exception = HTTPException(status_code=status.HTTP_401_UNAUTHORIZED, detail='Could not validate credentials')
    try:
        payload = jwt.decode(token, settings.secret_key, algorithms=[ALGORITHM])
        email = payload.get('sub')
        if email is None:
            raise credentials_exception
    except JWTError:
        raise credentials_exception
    user = db.query(User).filter(User.email == email).first()
    if not user or not user.is_active:
        raise credentials_exception
    return user
