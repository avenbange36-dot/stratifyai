from functools import lru_cache
from pydantic_settings import BaseSettings

class Settings(BaseSettings):
    app_name: str = 'StratifyAI Enterprise'
    app_env: str = 'development'
    secret_key: str = 'change-me'
    database_url: str = 'sqlite:///./stratifyai.db'
    cors_origins: str = 'http://localhost:5173'
    access_token_expire_minutes: int = 1440
    stripe_secret_key: str = ''
    stripe_price_id: str = ''
    stripe_webhook_secret: str = ''
    frontend_url: str = 'http://localhost:5173'
    demo_payment_mode: bool = True
    openai_api_key: str = ''
    openai_model: str = 'gpt-4.1-mini'
    saml_entity_id: str = ''
    saml_sso_url: str = ''
    saml_x509_cert: str = ''
    oidc_client_id: str = ''
    oidc_client_secret: str = ''
    oidc_issuer_url: str = ''
    secure_cookies: bool = False
    rate_limit_per_minute: int = 120
    audit_log_retention_days: int = 365
    support_email: str = 'support@yourdomain.com'

    class Config:
        env_file = '../.env'
        extra = 'ignore'

@lru_cache
def get_settings() -> Settings:
    return Settings()
