from io import BytesIO
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from reportlab.lib import colors
from app.services.consulting import generate_recommendations, governance_controls

def create_pdf_report(org, assessment):
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=letter)
    styles = getSampleStyleSheet()
    story = []
    story.append(Paragraph('StratifyAI Enterprise Readiness Report', styles['Title']))
    story.append(Spacer(1, 12))
    story.append(Paragraph(f'Client: {org.name}', styles['Heading2']))
    story.append(Paragraph(f'Industry: {org.industry}', styles['Normal']))
    story.append(Paragraph(f'Readiness score: {assessment.readiness_score}/100 ({assessment.maturity_band})', styles['Normal']))
    story.append(Spacer(1, 12))
    story.append(Paragraph('Recommended AI Initiatives', styles['Heading2']))
    data = [['Initiative', 'Function', 'Expected impact']]
    for item in generate_recommendations(org, assessment):
        data.append([item['title'], item['function'], item['impact']])
    table = Table(data, colWidths=[150, 100, 260])
    table.setStyle(TableStyle([('BACKGROUND',(0,0),(-1,0),colors.HexColor('#172033')),('TEXTCOLOR',(0,0),(-1,0),colors.white),('GRID',(0,0),(-1,-1),0.25,colors.grey),('VALIGN',(0,0),(-1,-1),'TOP')]))
    story.append(table)
    story.append(Spacer(1, 12))
    story.append(Paragraph('Governance Controls', styles['Heading2']))
    for c in governance_controls(assessment):
        story.append(Paragraph(f'• {c}', styles['Normal']))
    doc.build(story)
    buffer.seek(0)
    return buffer
