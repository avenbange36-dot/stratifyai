def readiness_score(payload):
    weights = {
        'data_quality': 0.22,
        'executive_alignment': 0.18,
        'ai_governance': 0.18,
        'security_maturity': 0.16,
        'process_standardization': 0.14,
        'change_management': 0.12,
    }
    raw = sum(getattr(payload, key) * weight for key, weight in weights.items())
    score = round((raw / 5) * 100, 1)
    if score >= 80:
        band = 'Scale-ready'
    elif score >= 65:
        band = 'Pilot-ready'
    elif score >= 45:
        band = 'Foundation required'
    else:
        band = 'High-risk transformation'
    return score, band

def generate_recommendations(org, assessment):
    industry = (org.industry or '').lower()
    generic = [
        {'title': 'AI opportunity portfolio', 'function': 'Strategy', 'impact': 'Prioritize AI initiatives by ROI, complexity, risk, and data readiness.'},
        {'title': 'AI governance operating model', 'function': 'Risk', 'impact': 'Create policies, review workflows, usage controls, and executive reporting.'},
        {'title': 'Enterprise knowledge assistant', 'function': 'Operations', 'impact': 'Reduce time spent searching policies, process docs, and customer/account information.'},
        {'title': 'Workflow automation backlog', 'function': 'Operations', 'impact': 'Identify manual processes suitable for AI-assisted automation and human-in-the-loop review.'},
    ]
    industry_specific = []
    if 'manufact' in industry:
        industry_specific += [
            {'title': 'Predictive maintenance advisor', 'function': 'Manufacturing', 'impact': 'Reduce downtime by predicting asset failures and recommending maintenance windows.'},
            {'title': 'AI quality inspection triage', 'function': 'Quality', 'impact': 'Prioritize inspection defects and improve first-pass yield.'},
        ]
    elif 'finance' in industry or 'bank' in industry or 'insurance' in industry:
        industry_specific += [
            {'title': 'Compliance evidence assistant', 'function': 'Compliance', 'impact': 'Summarize controls, map evidence, and reduce audit preparation time.'},
            {'title': 'Customer support copilot', 'function': 'Customer Experience', 'impact': 'Improve response quality while maintaining regulated review controls.'},
        ]
    elif 'health' in industry:
        industry_specific += [
            {'title': 'Administrative intake automation', 'function': 'Operations', 'impact': 'Reduce repetitive intake, coding, and documentation workflows.'},
            {'title': 'Policy and compliance assistant', 'function': 'Compliance', 'impact': 'Help staff navigate policies with auditable answer sources.'},
        ]
    else:
        industry_specific += [
            {'title': 'Revenue operations assistant', 'function': 'Sales', 'impact': 'Improve account planning, proposal creation, and renewal-risk detection.'},
            {'title': 'Finance close automation', 'function': 'Finance', 'impact': 'Reduce manual variance analysis and monthly reporting effort.'},
        ]
    return industry_specific + generic

def governance_controls(assessment):
    controls = []
    if assessment.ai_governance < 4:
        controls.append('Create an AI governance council with intake, risk-tiering, model approval, and monitoring workflows.')
    if assessment.data_quality < 4:
        controls.append('Launch a data quality remediation plan covering ownership, lineage, retention, and access classification.')
    if assessment.security_maturity < 4:
        controls.append('Require least-privilege access, prompt-injection testing, vendor security review, and sensitive-data redaction.')
    controls.append('Maintain an AI system inventory, approval status, business owner, data sources, model provider, and risk classification.')
    controls.append('Require human review for high-impact recommendations before deployment to customers, employees, or regulators.')
    return controls
