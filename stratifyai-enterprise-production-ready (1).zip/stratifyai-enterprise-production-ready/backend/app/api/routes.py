import json
from datetime import datetime
from pathlib import Path

import stripe
from fastapi import APIRouter, Depends, HTTPException, Request
from fastapi.responses import FileResponse, StreamingResponse
from sqlalchemy.orm import Session

from app.core.config import get_settings
from app.core.security import create_access_token, get_current_user, hash_password, verify_password
from app.db.session import get_db
from app.models.db_models import AuditLog, Assessment, EnterpriseSSOConfig, Organization, SecurityControl, Subscription, User
from app.models.schemas import (
    AssessmentCreate,
    AssessmentOut,
    AuditLogOut,
    CheckoutRequest,
    ControlUpdate,
    LoginRequest,
    OrganizationCreate,
    OrganizationOut,
    ProfileUpdate,
    SSOConfigIn,
    SSOConfigOut,
    Token,
    UserCreate,
    UserOut,
)
from app.services.consulting import generate_recommendations, governance_controls, readiness_score
from app.services.reports import create_pdf_report

router = APIRouter()
settings = get_settings()


def write_audit_log(db: Session, action: str, user: User | None = None, organization_id: int | None = None, request: Request | None = None, resource_type: str = '', resource_id: str = '', details: dict | None = None):
    log = AuditLog(
        organization_id=organization_id,
        actor_user_id=user.id if user else None,
        action=action,
        resource_type=resource_type,
        resource_id=str(resource_id or ''),
        ip_address=request.client.host if request and request.client else '',
        user_agent=request.headers.get('user-agent', '') if request else '',
        details=json.dumps(details or {}),
    )
    db.add(log)
    db.commit()


def assert_org_owner(db: Session, org_id: int, user: User) -> Organization:
    org = db.query(Organization).filter(Organization.id == org_id, Organization.owner_id == user.id).first()
    if not org:
        raise HTTPException(status_code=404, detail='Organization not found')
    return org


@router.get('/health')
def health():
    return {'status': 'ok', 'product': 'StratifyAI Enterprise', 'environment': settings.app_env}


@router.get('/security/posture')
def security_posture():
    return {
        'product': settings.app_name,
        'controls_enabled': ['password hashing', 'JWT auth', 'CORS restriction', 'audit log schema', 'Stripe webhook endpoint', 'SSO config stubs'],
        'controls_to_complete_before_production': ['real SSO integration', 'MFA enforcement', 'rate limiting middleware', 'SIEM export', 'SOC 2 audit', 'penetration test'],
    }


@router.post('/auth/register', response_model=Token)
def register(payload: UserCreate, request: Request, db: Session = Depends(get_db)):
    existing = db.query(User).filter(User.email == payload.email).first()
    if existing:
        raise HTTPException(status_code=400, detail='An account with this email already exists')
    user = User(email=payload.email, full_name=payload.full_name, hashed_password=hash_password(payload.password))
    db.add(user)
    db.commit()
    db.refresh(user)
    write_audit_log(db, 'user.registered', user=user, request=request, resource_type='user', resource_id=user.id)
    token = create_access_token(user.email)
    return {'access_token': token, 'token_type': 'bearer', 'user': user}


@router.post('/auth/login', response_model=Token)
def login(payload: LoginRequest, request: Request, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == payload.email).first()
    if not user or not verify_password(payload.password, user.hashed_password):
        raise HTTPException(status_code=401, detail='Invalid email or password')
    user.last_login_at = datetime.utcnow()
    db.commit()
    write_audit_log(db, 'user.login', user=user, request=request, resource_type='user', resource_id=user.id)
    return {'access_token': create_access_token(user.email), 'token_type': 'bearer', 'user': user}


@router.get('/auth/sso/start')
def sso_start(domain: str):
    return {
        'status': 'configuration_required',
        'message': 'This endpoint is a production SSO placeholder. Connect Auth0, WorkOS, Clerk Enterprise, Okta, or a SAML/OIDC library before enabling SSO login.',
        'requested_domain': domain,
    }


@router.get('/account/me', response_model=UserOut)
def me(current_user: User = Depends(get_current_user)):
    return current_user


@router.patch('/account/me', response_model=UserOut)
def update_me(payload: ProfileUpdate, request: Request, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    if payload.full_name:
        current_user.full_name = payload.full_name
    if payload.password:
        current_user.hashed_password = hash_password(payload.password)
    db.commit()
    db.refresh(current_user)
    write_audit_log(db, 'user.profile_updated', user=current_user, request=request, resource_type='user', resource_id=current_user.id)
    return current_user


@router.post('/organizations', response_model=OrganizationOut)
def create_org(payload: OrganizationCreate, request: Request, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    org = Organization(owner_id=current_user.id, **payload.model_dump())
    db.add(org)
    db.commit()
    db.refresh(org)
    sub = Subscription(organization_id=org.id, plan='trial', status='trial')
    db.add(sub)
    db.commit()
    write_audit_log(db, 'organization.created', user=current_user, organization_id=org.id, request=request, resource_type='organization', resource_id=org.id)
    return org


@router.get('/organizations', response_model=list[OrganizationOut])
def list_orgs(current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    return db.query(Organization).filter(Organization.owner_id == current_user.id).all()


@router.post('/assessments', response_model=AssessmentOut)
def create_assessment(payload: AssessmentCreate, request: Request, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    org = assert_org_owner(db, payload.organization_id, current_user)
    score, band = readiness_score(payload)
    assessment = Assessment(
        organization_id=org.id,
        data_quality=payload.data_quality,
        executive_alignment=payload.executive_alignment,
        ai_governance=payload.ai_governance,
        security_maturity=payload.security_maturity,
        process_standardization=payload.process_standardization,
        change_management=payload.change_management,
        goals=json.dumps(payload.goals),
        pain_points=json.dumps(payload.pain_points),
        readiness_score=score,
        maturity_band=band,
    )
    db.add(assessment)
    db.commit()
    db.refresh(assessment)
    write_audit_log(db, 'assessment.created', user=current_user, organization_id=org.id, request=request, resource_type='assessment', resource_id=assessment.id)
    return assessment


@router.get('/organizations/{org_id}/dashboard')
def dashboard(org_id: int, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    org = assert_org_owner(db, org_id, current_user)
    assessment = db.query(Assessment).filter(Assessment.organization_id == org.id).order_by(Assessment.id.desc()).first()
    if not assessment:
        return {'organization': org, 'assessment': None, 'recommendations': [], 'controls': []}
    return {
        'organization': {'id': org.id, 'name': org.name, 'industry': org.industry, 'employee_count': org.employee_count, 'annual_revenue_usd': org.annual_revenue_usd},
        'assessment': {'id': assessment.id, 'readiness_score': assessment.readiness_score, 'maturity_band': assessment.maturity_band},
        'recommendations': generate_recommendations(org, assessment),
        'controls': governance_controls(assessment),
        'roadmap': [
            {'phase': '0-30 days', 'focus': 'Confirm executive goals, inventory AI usage, and launch governance intake.'},
            {'phase': '31-90 days', 'focus': 'Run two high-value pilots with measurable ROI and human review.'},
            {'phase': '3-6 months', 'focus': 'Scale winning use cases, harden integrations, and formalize operating model.'},
            {'phase': '6-12 months', 'focus': 'Expand portfolio, track benefits, and prepare enterprise audit evidence.'},
        ],
    }


@router.get('/organizations/{org_id}/report.pdf')
def report_pdf(org_id: int, request: Request, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    org = assert_org_owner(db, org_id, current_user)
    assessment = db.query(Assessment).filter(Assessment.organization_id == org.id).order_by(Assessment.id.desc()).first()
    if not assessment:
        raise HTTPException(status_code=400, detail='Create an assessment first')
    pdf = create_pdf_report(org, assessment)
    write_audit_log(db, 'report.downloaded', user=current_user, organization_id=org.id, request=request, resource_type='organization', resource_id=org.id)
    return StreamingResponse(pdf, media_type='application/pdf', headers={'Content-Disposition': f'attachment; filename="{org.name}-stratifyai-report.pdf"'})


@router.post('/billing/checkout')
def create_checkout(payload: CheckoutRequest, request: Request, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    org = assert_org_owner(db, payload.organization_id, current_user)
    if settings.demo_payment_mode or not settings.stripe_secret_key or not settings.stripe_price_id:
        write_audit_log(db, 'billing.demo_checkout_started', user=current_user, organization_id=org.id, request=request, resource_type='organization', resource_id=org.id, details={'plan': payload.plan})
        return {'mode': 'demo', 'checkout_url': f'{settings.frontend_url}/#billing-success', 'message': 'Demo payment mode is on. Add Stripe keys in .env for live checkout.'}
    stripe.api_key = settings.stripe_secret_key
    session = stripe.checkout.Session.create(
        mode='subscription',
        payment_method_types=['card'],
        line_items=[{'price': settings.stripe_price_id, 'quantity': 1}],
        success_url=f'{settings.frontend_url}/#billing-success',
        cancel_url=f'{settings.frontend_url}/#pricing',
        customer_email=current_user.email,
        metadata={'organization_id': str(org.id), 'plan': payload.plan},
    )
    write_audit_log(db, 'billing.checkout_started', user=current_user, organization_id=org.id, request=request, resource_type='stripe_checkout', resource_id=session.id, details={'plan': payload.plan})
    return {'mode': 'stripe', 'checkout_url': session.url}


@router.post('/billing/webhook')
async def stripe_webhook(request: Request, db: Session = Depends(get_db)):
    payload = await request.body()
    sig_header = request.headers.get('stripe-signature', '')
    if not settings.stripe_webhook_secret:
        raise HTTPException(status_code=400, detail='Stripe webhook secret not configured')
    try:
        event = stripe.Webhook.construct_event(payload, sig_header, settings.stripe_webhook_secret)
    except Exception as exc:
        raise HTTPException(status_code=400, detail=f'Invalid Stripe webhook: {exc}')
    event_type = event.get('type')
    data = event.get('data', {}).get('object', {})
    org_id = None
    metadata = data.get('metadata') or {}
    if metadata.get('organization_id'):
        org_id = int(metadata['organization_id'])
    if event_type == 'checkout.session.completed' and org_id:
        sub = db.query(Subscription).filter(Subscription.organization_id == org_id).first()
        if sub:
            sub.status = 'active'
            sub.plan = metadata.get('plan', sub.plan)
            sub.stripe_customer_id = data.get('customer') or ''
            sub.stripe_subscription_id = data.get('subscription') or ''
            db.commit()
    write_audit_log(db, f'stripe.{event_type}', organization_id=org_id, request=request, resource_type='stripe_event', resource_id=event.get('id', ''), details={'type': event_type})
    return {'received': True}


@router.post('/enterprise/sso', response_model=SSOConfigOut)
def upsert_sso(payload: SSOConfigIn, request: Request, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    org = assert_org_owner(db, payload.organization_id, current_user)
    cfg = db.query(EnterpriseSSOConfig).filter(EnterpriseSSOConfig.organization_id == org.id).first()
    if not cfg:
        cfg = EnterpriseSSOConfig(organization_id=org.id)
        db.add(cfg)
    for key, value in payload.model_dump(exclude={'organization_id'}).items():
        setattr(cfg, key, value)
    cfg.updated_at = datetime.utcnow()
    db.commit()
    db.refresh(cfg)
    write_audit_log(db, 'enterprise.sso_config_updated', user=current_user, organization_id=org.id, request=request, resource_type='sso_config', resource_id=cfg.id, details={'enabled': cfg.enabled, 'provider': cfg.provider})
    return cfg


@router.get('/organizations/{org_id}/audit-logs', response_model=list[AuditLogOut])
def get_audit_logs(org_id: int, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    assert_org_owner(db, org_id, current_user)
    return db.query(AuditLog).filter(AuditLog.organization_id == org_id).order_by(AuditLog.created_at.desc()).limit(100).all()


@router.post('/security/controls')
def upsert_security_control(payload: ControlUpdate, request: Request, current_user: User = Depends(get_current_user), db: Session = Depends(get_db)):
    org = assert_org_owner(db, payload.organization_id, current_user)
    control = db.query(SecurityControl).filter(SecurityControl.organization_id == org.id, SecurityControl.control_id == payload.control_id).first()
    if not control:
        control = SecurityControl(organization_id=org.id, control_id=payload.control_id, title=payload.title)
        db.add(control)
    control.title = payload.title
    control.status = payload.status
    control.owner = payload.owner
    control.evidence_url = payload.evidence_url
    control.updated_at = datetime.utcnow()
    db.commit()
    write_audit_log(db, 'security.control_updated', user=current_user, organization_id=org.id, request=request, resource_type='security_control', resource_id=control.control_id, details={'status': control.status})
    return {'status': 'saved', 'control_id': control.control_id}


@router.get('/downloads/software')
def download_software():
    candidates = [
        Path(__file__).resolve().parents[3] / 'frontend' / 'public' / 'downloads' / 'stratifyai-enterprise-foundation.zip',
        Path(__file__).resolve().parents[3] / 'downloads' / 'stratifyai-enterprise-foundation.zip',
    ]
    for path in candidates:
        if path.exists():
            return FileResponse(path, media_type='application/zip', filename='stratifyai-enterprise-foundation.zip')
    raise HTTPException(status_code=404, detail='Download package not found. Rebuild the release archive from the project root.')
